"""Quality gates: compare aggregate metrics to thresholds.yaml."""
from dataclasses import dataclass

import yaml


@dataclass
class GateResult:
    metric: str
    value: float
    limit: float
    kind: str      # "min" or "max"
    passed: bool


def load_thresholds(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)["gates"]


def check_gates(metrics: dict, thresholds: dict) -> list[GateResult]:
    results = []
    for metric, rule in thresholds.items():
        value = metrics[metric]
        if "min" in rule:
            results.append(GateResult(metric, value, rule["min"], "min", value >= rule["min"]))
        if "max" in rule:
            results.append(GateResult(metric, value, rule["max"], "max", value <= rule["max"]))
    return results
