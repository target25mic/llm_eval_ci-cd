"""Metric definitions. Deliberately simple and deterministic (no LLM-as-judge) so every
number can be explained in an interview. See README for how to upgrade to LLM judges."""
import re

from app.llm import REFUSAL
from app.text import content_tokens, split_sentences

REFUSAL_PATTERNS = ("don't have enough information", "do not have enough information", "i don't know", "cannot answer")


def is_refusal(answer: str) -> bool:
    a = answer.lower()
    return any(p in a for p in REFUSAL_PATTERNS)


def answer_relevance(case: dict, answer: str) -> float:
    """Answerable Q: fraction of expected key facts found in the answer.
    Unanswerable Q: 1.0 if the system correctly refused, else 0.0."""
    if case["must_refuse"]:
        return 1.0 if is_refusal(answer) else 0.0
    if is_refusal(answer):
        return 0.0
    a = answer.lower()
    facts = case["key_facts"]
    return sum(f.lower() in a for f in facts) / len(facts)


def faithfulness(answer: str, context: str, support_threshold: float = 0.8) -> float:
    """Fraction of answer sentences whose content words are (>=80%) present in the retrieved context.
    A refusal makes no claims, so it is trivially faithful."""
    if is_refusal(answer):
        return 1.0
    ctx = set(content_tokens(context))
    sents = split_sentences(answer)
    if not sents:
        return 0.0
    supported = 0
    for s in sents:
        toks = content_tokens(s)
        if toks and sum(t in ctx for t in toks) / len(toks) >= support_threshold:
            supported += 1
    return supported / len(sents)


def is_hallucination(case: dict, answer: str, faith: float) -> bool:
    """Hallucination = made-up content (unsupported sentence) OR answering a question that has no answer."""
    if case["must_refuse"] and not is_refusal(answer):
        return True
    return faith < 1.0


def percentile(values: list[float], p: float) -> float:
    s = sorted(values)
    idx = max(0, min(len(s) - 1, int(-(-p * len(s) // 1)) - 1))   # ceil(p*n)-1
    return s[idx]
