"""Push run-level metrics to a Prometheus Pushgateway (batch jobs can't be scraped directly)."""
import os

from prometheus_client import CollectorRegistry, Gauge, push_to_gateway

GAUGES = {
    "answer_relevance": "Average answer relevance (0-1)",
    "faithfulness": "Average faithfulness to retrieved context (0-1)",
    "hallucination_rate": "Share of cases that hallucinated (0-1)",
    "latency_avg_seconds": "Average latency per query",
    "latency_p95_seconds": "p95 latency per query",
    "cost_per_query_usd": "Average cost per query in USD",
    "gate_passed": "1 if all quality gates passed, else 0",
    "cases_total": "Number of golden cases evaluated",
}


def push_metrics(metrics: dict, gate_passed: bool, prompt_version: str, git_sha: str) -> bool:
    url = os.environ.get("PUSHGATEWAY_URL")
    if not url:
        return False
    reg = CollectorRegistry()
    labels = dict(prompt_version=prompt_version, git_sha=git_sha)
    values = {**metrics, "gate_passed": 1.0 if gate_passed else 0.0}
    for name, doc in GAUGES.items():
        if name in values:
            Gauge(f"llm_eval_{name}", doc, list(labels), registry=reg).labels(**labels).set(values[name])
    try:
        push_to_gateway(url, job="llm_eval", registry=reg)
        return True
    except Exception as exc:  # monitoring must never break the evaluation itself
        print(f"[warn] could not push to Pushgateway at {url}: {exc}")
        return False
