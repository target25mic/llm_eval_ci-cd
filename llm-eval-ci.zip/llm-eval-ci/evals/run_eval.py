"""Run the golden dataset through the pipeline, score it, apply gates, write reports.

    python -m evals.run_eval            # exit code 1 if any gate fails (this is what CI uses)
    python -m evals.run_eval --no-fail  # always exit 0 (for demos)
"""
import argparse
import json
import os
import statistics
import sys

from app.config import load_config
from app.pipeline import RAGPipeline
from evals.gates import check_gates, load_thresholds
from evals.metrics import answer_relevance, faithfulness, is_hallucination, percentile
from evals.prom import push_metrics

ROOT = os.path.join(os.path.dirname(__file__), "..")


def run(dataset_path: str, cfg) -> tuple[list[dict], dict]:
    pipe = RAGPipeline(cfg)
    with open(dataset_path) as f:
        cases = json.load(f)
    rows = []
    for case in cases:
        r = pipe.answer(case["question"])
        faith = faithfulness(r.answer, r.context)
        rows.append({
            "id": case["id"], "category": case["category"], "question": case["question"],
            "expected": case["expected_answer"], "answer": r.answer, "retrieved": r.retrieved_ids,
            "relevance": answer_relevance(case, r.answer), "faithfulness": faith,
            "hallucinated": is_hallucination(case, r.answer, faith),
            "latency_s": r.latency_s, "cost_usd": r.cost_usd,
        })
    lat = [x["latency_s"] for x in rows]
    n = len(rows)
    metrics = {
        "answer_relevance": statistics.mean(x["relevance"] for x in rows),
        "faithfulness": statistics.mean(x["faithfulness"] for x in rows),
        "hallucination_rate": sum(x["hallucinated"] for x in rows) / n,
        "latency_avg_seconds": statistics.mean(lat),
        "latency_p95_seconds": percentile(lat, 0.95),
        "cost_per_query_usd": statistics.mean(x["cost_usd"] for x in rows),
        "cases_total": n,
    }
    return rows, metrics


def write_reports(rows, metrics, gates, cfg, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "results.json"), "w") as f:
        json.dump({"config": cfg.__dict__, "metrics": metrics,
                   "gates": [g.__dict__ for g in gates], "cases": rows}, f, indent=2)
    ok = all(g.passed for g in gates)
    md = [f"## LLM Evaluation: {'✅ PASSED' if ok else '❌ FAILED'}",
          f"`prompt={cfg.prompt_version}` `top_k={cfg.top_k}` `backend={cfg.llm_backend}` `sha={cfg.git_sha}`\n",
          "| Gate | Value | Limit | Result |", "|---|---|---|---|"]
    for g in gates:
        op = "≥" if g.kind == "min" else "≤"
        md.append(f"| {g.metric} | {g.value:.4f} | {op} {g.limit} | {'✅' if g.passed else '❌'} |")
    bad = [r for r in rows if r["relevance"] < 1 or r["hallucinated"]]
    if bad:
        md += ["", f"### Problem cases ({len(bad)})", "| id | question | answer | rel | halluc |", "|---|---|---|---|---|"]
        for r in bad[:15]:
            md.append(f"| {r['id']} | {r['question']} | {r['answer'][:70]} | {r['relevance']:.2f} | {r['hallucinated']} |")
    with open(os.path.join(out_dir, "summary.md"), "w") as f:
        f.write("\n".join(md) + "\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default=os.path.join(ROOT, "data", "golden_dataset.json"))
    ap.add_argument("--thresholds", default=os.path.join(ROOT, "thresholds.yaml"))
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    ap.add_argument("--no-fail", action="store_true")
    args = ap.parse_args()

    cfg = load_config()
    rows, metrics = run(args.dataset, cfg)
    gates = check_gates(metrics, load_thresholds(args.thresholds))
    passed = all(g.passed for g in gates)
    write_reports(rows, metrics, gates, cfg, args.out)
    pushed = push_metrics(metrics, passed, cfg.prompt_version, cfg.git_sha)

    print(f"\nLLM evaluation | prompt={cfg.prompt_version} top_k={cfg.top_k} cases={metrics['cases_total']}")
    for g in gates:
        op = ">=" if g.kind == "min" else "<="
        print(f"  [{'PASS' if g.passed else 'FAIL'}] {g.metric:<22} {g.value:.4f}  (need {op} {g.limit})")
    if pushed:
        print("  metrics pushed to Prometheus Pushgateway")
    print("RESULT:", "PASSED" if passed else "FAILED (quality gate violated)")
    return 0 if (passed or args.no_fail) else 1


if __name__ == "__main__":
    sys.exit(main())
