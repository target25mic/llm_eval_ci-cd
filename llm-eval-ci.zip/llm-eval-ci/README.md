# LLM Evaluation CI/CD Pipeline

A small, runnable project that answers one question:

> **"If someone changes a prompt, the retrieval code, or the model, how do we *know* the AI didn't get worse — before it ships?"**

Regular code has unit tests. LLM apps need the same safety net, but outputs are free text, so we score
them with **metrics** against a **golden dataset** and fail the build when scores drop.

Everything runs locally with **no API keys** (a deterministic mock LLM stands in for the model).

---

## 1. Big picture

```
 git push / PR
      │
      ▼
┌──────────────────── GitHub Actions ─────────────────────────┐
│ 1. pytest              → tests the evaluation code itself    │
│ 2. evals.run_eval      → runs 42 golden questions through    │
│                           the RAG app, scores each answer     │
│ 3. quality gates       → thresholds.yaml; any miss => exit 1  │
│ 4. report + artifact   → summary on the PR, results.json      │
│ 5. docker job          → same eval inside the container       │
└───────────────────────────────┬──────────────────────────────┘
                                │ (optional) push metrics
                                ▼
                  Pushgateway → Prometheus → Grafana   (trends across runs)
```

## 2. Repo map (read in this order)

| File | What it teaches |
|---|---|
| `data/knowledge_base.json` | The documents the RAG app can retrieve from (fictional "AcmeCloud") |
| `app/retriever.py` | **R**etrieval: BM25 scoring written from scratch |
| `app/prompts.py` | Prompt versions as code (`v1` good, `v2_regressed` bad) |
| `app/llm.py` | **G**eneration: mock LLM (+ real Anthropic backend behind `LLM_BACKEND=anthropic`) |
| `app/pipeline.py` | retrieve → prompt → generate, and measures latency + cost per query |
| `data/golden_dataset.json` | **42 questions**: 31 factual, 6 unanswerable, 3 adversarial, 2 typo edge cases |
| `evals/metrics.py` | How relevance, faithfulness and hallucination are computed |
| `evals/gates.py` + `thresholds.yaml` | **Quality gates**: pass/fail rules |
| `evals/run_eval.py` | The runner: score, gate, write reports, exit 0/1 |
| `.github/workflows/llm-eval.yml` | CI wiring |
| `Dockerfile`, `docker-compose.yml`, `monitoring/` | Containerisation + Prometheus/Grafana |

## 3. The metrics (all deterministic, so you can explain them)

| Metric | Definition | Why it matters |
|---|---|---|
| **Answer relevance** | Share of the case's expected `key_facts` found in the answer. For unanswerable questions: 1 if the system refused, else 0 | Did it actually answer the question? |
| **Faithfulness** | Share of answer sentences whose content words are ≥80% present in the *retrieved context* | Is the answer grounded in sources? |
| **Hallucination rate** | Share of cases with an unsupported sentence **or** a confident answer to an unanswerable question | The failure users notice most |
| **Latency (avg, p95)** | Wall-clock per query (retrieval + generation) | p95 shows the slow tail, not just the average |
| **Cost / query** | `(prompt_tokens × $in + completion_tokens × $out)`, token counts estimated | Longer prompts / bigger top-k quietly raise your bill |

> Production note: these are cheap, reproducible proxies. In a real system you would add an
> **LLM-as-judge** (e.g. a grader prompt returning a 1-5 score) for relevance/faithfulness and keep these
> as fast first-pass checks. Know the trade-off: judges are more flexible but slower, costlier and noisy.

## 4. Run it

```bash
pip install -r requirements.txt
make test                  # 7 unit tests
make eval                  # PASSED, exit code 0
```

### See a regression get caught

```bash
make eval-bad-prompt       # PROMPT_VERSION=v2_regressed  → faithfulness + hallucination gates FAIL
make eval-bad-retrieval    # RAG_MIN_SCORE=50 (retrieval finds nothing) → relevance gate FAILS
RAG_TOP_K=13 PRICE_INPUT_PER_MTOK=10 python -m evals.run_eval   # cost gate FAILS
MOCK_LLM_LATENCY_MS=700 python -m evals.run_eval                # latency gate FAILS
```
Each one exits with code **1**. That non-zero exit code is the *entire* mechanism by which CI turns red.

## 5. Dashboards (Docker)

```bash
make up          # Pushgateway :9091, Prometheus :9090, Grafana :3000
make demo        # good → bad → fixed runs, ~1.5 min
```
Open <http://localhost:3000> → dashboard **LLM Evaluation Quality**. You will see relevance/faithfulness dip
and hallucination spike during the "bad" runs. Run the eval inside Docker with `make docker-eval`. Stop with `make down`.

*Why Pushgateway?* An eval is a short-lived batch job. Prometheus *pulls* from long-running servers, so a job
that finishes in 2 seconds would be missed. The job **pushes** its final numbers to Pushgateway, which Prometheus scrapes.

## 6. Make CI actually block merges

1. Push to GitHub. The workflow runs on PRs touching `app/**`, `data/**`, `evals/**`, `thresholds.yaml`.
2. Repo → Settings → Branches → add a rule on `main` → **Require status checks** → select `evaluate`.
3. Now a PR that lowers quality cannot be merged. Open one that sets `PROMPT_VERSION` default to `v2_regressed` and watch it fail.

## 7. Exercises (in increasing difficulty)

1. **Add 5 golden questions** (include one tricky edge case). Does the pipeline still pass? If something fails, is the *data* wrong or the *app*?
2. **Add a gate** `min_pass_rate` = share of cases with relevance == 1.0. Touch `run_eval.py` + `thresholds.yaml` + a unit test.
3. **Break retrieval subtly**: remove the `title` from the BM25 index in `retriever.py`. Which cases regress? Which metric moves?
4. **Per-category scores**: report relevance for `factual` vs `edge_*` separately and gate the edge categories.
5. **Compare to baseline**: save `results.json` from `main` and fail the PR if relevance drops by more than 2 points (a *relative* gate instead of an absolute one).
6. **Swap in a real model**: `pip install anthropic`, set `LLM_BACKEND=anthropic ANTHROPIC_API_KEY=...`. Which gates now fail, and why? (Hint: real models are verbose, and non-deterministic. How would you handle flaky evals?)
7. **LLM-as-judge**: add a metric that asks a model to grade faithfulness 1-5. Compare it with the heuristic.

## 8. Questions to be able to answer

- Why is a *golden dataset* better than eyeballing a few outputs? What makes a good one (coverage, edge cases, versioned in git)?
- Faithfulness vs. answer relevance: give an answer that is faithful but irrelevant, and one relevant but unfaithful.
- Why gate on **p95** latency rather than the average?
- A gate fails on a PR: how do you decide between "fix the code" and "update the threshold/dataset"?
- What would make these evals flaky with a real LLM, and how do you mitigate it (temperature 0, multiple samples, tolerance bands)?
- Where would you put this pipeline relative to deployment (PR gate vs. nightly full eval vs. post-deploy monitoring)?
