"""Prompt versions live in code so a prompt change is a normal reviewable diff.
CI re-runs the evaluation on every change to this file."""

PROMPTS = {
    # Grounded prompt: only answer from context, otherwise refuse.
    "v1": (
        "You are a support assistant for AcmeCloud.\n"
        "Answer ONLY using the context below. If the answer is not in the context, "
        "reply exactly: \"I don't have enough information to answer that.\"\n\n"
        "Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    ),
    # A 'well-meaning' edit that tells the model to be helpful no matter what.
    # The mock LLM reproduces the classic failure: it stops refusing and pads answers.
    "v2_regressed": (
        "You are a friendly assistant for AcmeCloud. Always give a helpful, detailed answer, "
        "using the context and your general knowledge.\n\n"
        "Context:\n{context}\n\nQuestion: {question}\nAnswer:"
    ),
}
