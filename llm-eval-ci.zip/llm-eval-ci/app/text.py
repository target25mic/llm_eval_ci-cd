"""Tiny text utilities shared by retriever, mock LLM and metrics."""
import re

STOPWORDS = set("""
a an the is are was were be been of to in on at for and or but how what who whom when where which why
do does did can could i my me you your it its with by from that this there as if will would per after
before than any up much many long all have has had get gets got about into acmecloud s tell
""".split())


def stem(t: str) -> str:
    """Very light stemmer: enough to match 'includes'/'included'/'include'."""
    if len(t) > 4 and t.endswith("ing"):
        t = t[:-3]
    elif len(t) > 4 and t.endswith("ed"):
        t = t[:-2]
    elif len(t) > 3 and t.endswith("s") and not t.endswith("ss"):
        t = t[:-1]
    if len(t) > 3 and t.endswith("e"):
        t = t[:-1]
    return t


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def content_tokens(text: str) -> list[str]:
    return [stem(t) for t in tokenize(text) if t not in STOPWORDS and (len(t) > 1 or t.isdigit())]


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]


def estimate_tokens(text: str) -> int:
    """Rough token estimate (~1.33 tokens per word). Good enough for cost tracking."""
    return max(1, int(len(text.split()) * 1.33))
