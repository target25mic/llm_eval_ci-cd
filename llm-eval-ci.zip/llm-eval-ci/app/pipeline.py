"""The 'application under test': retrieve -> build prompt -> generate -> measure."""
import os
import time
from dataclasses import dataclass

from app.config import Config, load_config
from app.llm import REFUSAL, get_llm
from app.prompts import PROMPTS
from app.retriever import BM25Retriever
from app.text import estimate_tokens

KB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base.json")


@dataclass
class Result:
    answer: str
    retrieved_ids: list
    context: str
    prompt_tokens: int
    completion_tokens: int
    cost_usd: float
    latency_s: float


class RAGPipeline:
    def __init__(self, cfg: Config | None = None, kb_path: str = KB_PATH, llm=None):
        self.cfg = cfg or load_config()
        self.retriever = BM25Retriever.from_json(kb_path)
        self.llm = llm or get_llm(self.cfg)

    def answer(self, question: str) -> Result:
        t0 = time.perf_counter()
        hits = self.retriever.search(question, self.cfg.top_k, self.cfg.min_retrieval_score)
        chunks = [c for c, _ in hits]
        context = "\n".join(f"[{c.id}] {c.text}" for c in chunks)
        prompt = PROMPTS[self.cfg.prompt_version].format(context=context or "(none)", question=question)
        answer = self.llm.generate(prompt, question, chunks) if chunks else REFUSAL
        latency = time.perf_counter() - t0
        pt, ct = estimate_tokens(prompt), estimate_tokens(answer)
        cost = (pt * self.cfg.price_in_per_mtok + ct * self.cfg.price_out_per_mtok) / 1e6
        return Result(answer, [c.id for c in chunks], " ".join(c.text for c in chunks), pt, ct, cost, latency)
