"""BM25 retriever written from scratch (no deps) so you can read how retrieval scoring works."""
import json
import math
from collections import Counter
from dataclasses import dataclass

from app.text import content_tokens


@dataclass
class Chunk:
    id: str
    title: str
    text: str


class BM25Retriever:
    def __init__(self, chunks: list[Chunk], k1: float = 1.5, b: float = 0.75):
        self.chunks, self.k1, self.b = chunks, k1, b
        self.docs = [content_tokens(c.title + " " + c.text) for c in chunks]
        self.avgdl = sum(len(d) for d in self.docs) / len(self.docs)
        df = Counter(t for d in self.docs for t in set(d))
        n = len(self.docs)
        self.idf = {t: math.log(1 + (n - f + 0.5) / (f + 0.5)) for t, f in df.items()}

    @classmethod
    def from_json(cls, path: str) -> "BM25Retriever":
        with open(path) as f:
            return cls([Chunk(**d) for d in json.load(f)])

    def search(self, query: str, k: int = 3, min_score: float = 0.0):
        q = content_tokens(query)
        scored = []
        for chunk, doc in zip(self.chunks, self.docs):
            tf = Counter(doc)
            score = 0.0
            for t in q:
                if t in tf:
                    num = tf[t] * (self.k1 + 1)
                    den = tf[t] + self.k1 * (1 - self.b + self.b * len(doc) / self.avgdl)
                    score += self.idf[t] * num / den
            if score > min_score:
                scored.append((chunk, score))
        scored.sort(key=lambda x: -x[1])
        return scored[:k]
