"""LLM backends. The default MockLLM is deterministic and free, so CI is stable.
Set LLM_BACKEND=anthropic (+ ANTHROPIC_API_KEY, pip install anthropic) to use a real model."""
import time

from app.config import Config
from app.text import content_tokens, split_sentences

REFUSAL = "I don't have enough information to answer that."
FLUFF = ("Additionally, all plans include a complimentary 14-day premium trial "
         "and priority onboarding with a personal concierge.")


class MockLLM:
    """Extractive 'LLM': returns the context sentences that best cover the question.
    It exists so you can watch the evaluation pipeline work without paying for tokens."""

    def __init__(self, cfg: Config):
        self.cfg = cfg

    def generate(self, prompt: str, question: str, chunks) -> str:
        time.sleep(self.cfg.mock_latency_ms / 1000)
        q = set(content_tokens(question))
        scored = []
        for rank, chunk in enumerate(chunks):
            for sent in split_sentences(chunk.text):
                cov = len(q & set(content_tokens(sent))) / len(q) if q else 0.0
                scored.append((cov, -rank, sent))
        scored.sort(reverse=True)
        regressed = self.cfg.prompt_version == "v2_regressed"
        if not scored or scored[0][0] < self.cfg.min_coverage:
            return FLUFF if regressed else REFUSAL      # v2 never says "I don't know"
        best = scored[0][0]
        picked = [s for c, _, s in scored if c >= max(best * 0.9, self.cfg.min_coverage)][:2]
        answer = " ".join(picked)
        return answer + " " + FLUFF if regressed else answer


class AnthropicLLM:
    def __init__(self, cfg: Config):
        import anthropic  # lazy import: only needed for the real backend
        self.client, self.cfg = anthropic.Anthropic(), cfg

    def generate(self, prompt: str, question: str, chunks) -> str:
        msg = self.client.messages.create(
            model=self.cfg.llm_model, max_tokens=300,
            messages=[{"role": "user", "content": prompt}],
        )
        return msg.content[0].text.strip()


def get_llm(cfg: Config):
    return AnthropicLLM(cfg) if cfg.llm_backend == "anthropic" else MockLLM(cfg)
