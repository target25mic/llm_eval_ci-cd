"""All tunables come from environment variables, so CI can change behaviour
(prompt version, retrieval settings, model) without editing code."""
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    prompt_version: str
    top_k: int
    min_retrieval_score: float
    min_coverage: float
    llm_backend: str          # "mock" (default, no API key) or "anthropic"
    llm_model: str
    mock_latency_ms: float
    price_in_per_mtok: float  # USD per 1M input tokens
    price_out_per_mtok: float # USD per 1M output tokens
    git_sha: str


def load_config() -> Config:
    e = os.environ.get
    return Config(
        prompt_version=e("PROMPT_VERSION", "v1"),
        top_k=int(e("RAG_TOP_K", "3")),
        min_retrieval_score=float(e("RAG_MIN_SCORE", "0.1")),
        min_coverage=float(e("RAG_MIN_COVERAGE", "0.5")),
        llm_backend=e("LLM_BACKEND", "mock"),
        llm_model=e("LLM_MODEL", "claude-haiku-5-5"),
        mock_latency_ms=float(e("MOCK_LLM_LATENCY_MS", "20")),
        price_in_per_mtok=float(e("PRICE_INPUT_PER_MTOK", "1.0")),
        price_out_per_mtok=float(e("PRICE_OUTPUT_PER_MTOK", "5.0")),
        git_sha=e("GIT_SHA", "local")[:7],
    )
