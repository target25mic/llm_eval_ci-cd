"""Fast unit tests for the evaluation framework itself (no full eval run)."""
import json
import os

import pytest

from app.config import load_config
from app.pipeline import RAGPipeline
from evals.gates import check_gates
from evals.metrics import answer_relevance, faithfulness, is_hallucination, is_refusal, percentile

ROOT = os.path.join(os.path.dirname(__file__), "..")


@pytest.fixture(scope="module")
def pipe():
    return RAGPipeline(load_config())


def test_golden_dataset_is_well_formed():
    cases = json.load(open(os.path.join(ROOT, "data", "golden_dataset.json")))
    assert len(cases) >= 30
    assert {"factual", "edge_unanswerable", "edge_adversarial", "edge_typo"} <= {c["category"] for c in cases}
    for c in cases:
        assert c["question"] and c["expected_answer"]
        assert c["must_refuse"] or c["key_facts"], f"{c['id']} needs key_facts"


def test_retriever_finds_right_document(pipe):
    assert pipe.answer("How much does the Pro plan cost?").retrieved_ids[0] == "pricing"


def test_pipeline_refuses_unanswerable(pipe):
    assert is_refusal(pipe.answer("Who is the CEO of AcmeCloud?").answer)


def test_faithfulness_detects_invented_sentence():
    ctx = "The Pro plan costs $20 per user per month."
    assert faithfulness("The Pro plan costs $20 per user per month.", ctx) == 1.0
    assert faithfulness("The Pro plan costs $20 per user per month. It includes a free helicopter ride.", ctx) == 0.5


def test_relevance_and_hallucination_rules():
    ans_case = {"must_refuse": False, "key_facts": ["30 days", "refund"]}
    assert answer_relevance(ans_case, "Refunds within 30 days.") == 1.0
    assert answer_relevance(ans_case, "Refunds within 30 days.") == 1.0
    assert answer_relevance(ans_case, "I don't have enough information to answer that.") == 0.0
    no_ans = {"must_refuse": True, "key_facts": []}
    assert is_hallucination(no_ans, "It costs $5.", 1.0) is True
    assert is_hallucination(no_ans, "I don't have enough information to answer that.", 1.0) is False


def test_gates_fail_when_threshold_violated():
    thresholds = {"faithfulness": {"min": 0.95}, "latency_p95_seconds": {"max": 0.5}}
    ok = check_gates({"faithfulness": 0.99, "latency_p95_seconds": 0.1}, thresholds)
    bad = check_gates({"faithfulness": 0.80, "latency_p95_seconds": 0.9}, thresholds)
    assert all(g.passed for g in ok)
    assert not any(g.passed for g in bad)


def test_percentile():
    assert percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.95) == 10
    assert percentile([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 0.5) == 5
