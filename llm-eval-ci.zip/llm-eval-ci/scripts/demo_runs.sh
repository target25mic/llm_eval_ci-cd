#!/usr/bin/env bash
# Pushes several runs (good, bad, good) to Pushgateway so Grafana shows a trend with a regression.
# Needs: `make up` first. Open Grafana at http://localhost:3000
export PUSHGATEWAY_URL=${PUSHGATEWAY_URL:-http://localhost:9091}
for i in 1 2; do GIT_SHA=good$i python -m evals.run_eval --no-fail >/dev/null; sleep 12; done
for i in 1 2; do GIT_SHA=bad$i PROMPT_VERSION=v2_regressed python -m evals.run_eval --no-fail >/dev/null; sleep 12; done
for i in 1 2; do GIT_SHA=fixed$i python -m evals.run_eval --no-fail >/dev/null; sleep 12; done
echo "Done. Look at the dashboard: relevance/faithfulness dip during the 'bad' runs."
